package com.aurexon.editor;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.media3.common.MediaItem;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.Transformer;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;

import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private VideoView preview;
    private TextView emptyHint, durationLabel, importButton, playButton, exportButton;
    private SeekBar startSeek, endSeek;
    private Uri videoUri;
    private long durationMs = 0;
    private long startMs = 0;
    private long endMs = 0;
    private Transformer transformer;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        preview = findViewById(R.id.videoPreview);
        emptyHint = findViewById(R.id.emptyHint);
        durationLabel = findViewById(R.id.durationLabel);
        importButton = findViewById(R.id.importButton);
        playButton = findViewById(R.id.playButton);
        exportButton = findViewById(R.id.exportButton);
        startSeek = findViewById(R.id.startSeek);
        endSeek = findViewById(R.id.endSeek);

        importButton.setOnClickListener(v -> chooseVideo());
        playButton.setOnClickListener(v -> {
            if (videoUri == null) { toast("Add a video first"); return; }
            if (preview.isPlaying()) preview.pause(); else preview.start();
        });
        startSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) { startMs = Math.min(p * 1000L, Math.max(0, endMs - 1000)); updateLabels(); }
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        endSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean u) {
                if (u) { endMs = Math.max((p * 1000L), startMs + 1000); endMs = Math.min(endMs, durationMs); updateLabels(); }
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        exportButton.setOnClickListener(v -> exportVideo());
        updateLabels();
    }

    private void chooseVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            videoUri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(videoUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) {}
            preview.setVideoURI(videoUri);
            preview.setOnPreparedListener(mp -> {
                durationMs = mp.getDuration();
                endMs = durationMs;
                int seconds = Math.max(1, (int)(durationMs / 1000));
                startSeek.setMax(seconds);
                endSeek.setMax(seconds);
                startSeek.setProgress(0);
                endSeek.setProgress(seconds);
                emptyHint.setVisibility(View.GONE);
                updateLabels();
            });
            preview.requestFocus();
        }
    }

    private void exportVideo() {
        if (videoUri == null) { toast("Add a video first"); return; }
        if (endMs <= startMs) { toast("Choose a valid trim range"); return; }

        File outDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES);
        if (outDir == null) { toast("Storage unavailable"); return; }
        File output = new File(outDir, "Aurexon_" + System.currentTimeMillis() + ".mp4");

        MediaItem clipped = new MediaItem.Builder()
            .setUri(videoUri)
            .setClippingConfiguration(new MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build())
            .build();
        EditedMediaItem edited = new EditedMediaItem.Builder(clipped).build();

        exportButton.setEnabled(false);
        exportButton.setText("EXPORTING…");
        transformer = new Transformer.Builder(this)
            .addListener(new Transformer.Listener() {
                @Override public void onCompleted(Composition composition, ExportResult result) {
                    exportButton.setEnabled(true);
                    exportButton.setText("EXPORT");
                    toast("Export complete: " + output.getName() + " (saved in app Movies folder)");
                }
                @Override public void onError(Composition composition, ExportResult result, ExportException exception) {
                    exportButton.setEnabled(true);
                    exportButton.setText("EXPORT");
                    toast("Export failed: " + exception.getMessage());
                }
            }).build();
        transformer.start(edited, output.getAbsolutePath());
    }

    private void updateLabels() {
        durationLabel.setText("Start " + format(startMs) + "   •   End " + format(endMs));
    }
    private String format(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(Locale.getDefault(), "%02d:%02d", s / 60, s % 60);
    }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }
}
