# Aurexon Editor (Android starter)

A dark, CapCut-inspired Android video editor starter project.

## Included working features
- Import a video from the device using Android's document picker.
- Preview the selected video.
- Set trim start and trim end using timeline sliders.
- Export the trimmed clip to MP4 using AndroidX Media3 Transformer.

## Build
1. Install Android Studio (current stable) and Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync finish.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press Run.

## Export location
The app saves exports in its app-specific Movies folder:
`Android/data/com.aurexon.editor/files/Movies/`

The export is not yet copied into the public Gallery. The app currently focuses on a reliable first editing workflow.

## Current limitations
This is a first working MVP, not a full CapCut clone. It currently supports trimming and export only. Music tracks, text overlays, filters, transitions, multi-clip timelines, undo/redo, and public Gallery saving are planned next. Export performance and supported formats depend on the Android device and source video.

## Notes
- Package: `com.aurexon.editor`
- Minimum Android: 7.0 (API 24)
- Media3 Transformer: 1.5.1

## Build APK using only a phone (GitHub Actions)
This project includes `.github/workflows/build-apk.yml`. Upload the project files to a GitHub repository, then open the repository's Actions tab and run **Build Aurexon Editor APK**. The workflow builds a debug APK in GitHub's hosted runner and uploads it as an artifact. Download the artifact from the completed workflow run and extract the APK on your phone.
